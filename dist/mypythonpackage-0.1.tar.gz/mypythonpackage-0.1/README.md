# myPythonPackage

This package was created to learn and practice how to publish a python package.

# How to install

`pip install git+https://github.com/juluis-foyet/myPythonPackage.git`